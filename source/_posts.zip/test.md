---
title: test
copyright: true
abbrlink: d87f7e0c
date: 2018-01-26 11:19:04
tags:
categories:
---

域名防盗链测试：
![11][1]         ![22][2]
  



  图片处理：
  ![enter description here][3]
  

  
http://m10.music.126.net/20180403235510/7a0336debd973c86b5c21e8b21c753ae/ymusic/d6d3/7aac/9aed/802e6b3a1bd34a18927f4adab563690a.mp3

  


----------


 2018年03月22日 17时50分35秒
 因更新版本再次测试图床功能
 ![enter description here][4]


  [1]: http://data.singlelovely.cn/11.jpeg
  [2]: http://data.singlelovely.cn/12.jpeg?imageView2/2/w/250/h/300/q/75%7Cimageslim
  [3]: http://data.singlelovely.cn/13.jpeg?imageView2/2/w/250/h/200/q/75%7Cimageslim
  [4]: http://data.singlelovely.cn/xsj/2018/3/22/1478145958717.jpg "1478145958717"
  
外链测试：
  <iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="//music.163.com/outchain/player?type=2&id=400581235&auto=0&height=66"></iframe>
  
  <iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="//music.163.com/outchain/player?type=2&id=543987400&auto=1&height=66"></iframe>

/outchain/2/298317/

<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=330 height=86 src="//music.163.com/outchain/2/298317&auto=1&height=66"></iframe>


米兰的小铁匠

<embed src="http://www.xiami.com/widget/0_1775256378/singlePlayer.swf" type="application/x-shockwave-flash" width="257" height="33" wmode="transparent"></embed>

<script type="text/javascript" src="http://www.xiami.com/widget/player-single?uid=0&sid=1775256378&mode=js"></script>

<audio src="http://www.xiami.com/widget/0_1775256378/singlePlayer.swf" type="application/x-shockwave-flash" width="257" height="33" wmode="transparent"></audio>


{% meting "21637275" "xiami" "playlist"  "mutex:true" "listmaxheight:340px" "preload:none" "theme:#ad7a86"%}



![001](https://images.unsplash.com/photo-1461529959205-ba7d61debd0b?ixlib=rb-0.3.5&q=80&fm=jpg&crop=entropy&w=400&fit=max&s=0653332e9c1498112a303c583c102f6a)
![002](https://data.singlelovely.cn/CoverPicture/1a300c2b.png!CoverPicture)