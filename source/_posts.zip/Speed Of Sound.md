---
title: Speed Of Sound
copyright: false
abbrlink: 1bb05bfb
notshow: false
description: How long do I have climb up on the side of this mountain of mine?
sticky: 2
date: 2018-08-16 16:52:00
tags: 
categories: 音乐
password:
photos: 
- "https://data.singlelovely.cn/CoverPicture/1bb05bfb.png!CoverPicture"
image:
---
</br>

**未知之神，何时我才能在我的高处俯视，说：你们想升高时，就向上仰望。我向下俯视，因为我已升高？^[1]^**

</br>

<p id="div-border-left-purple">How long before I get in</br>
在我抵达之前已过了多久</br>
Before it starts before I begin</br>
在开启旅途之前 在我启程之前</br>
How long before you decide or</br>
在你做决定之前已过了多久</br>
Before I know what it feels like</br>
在我体会到这种远行的滋味之前</br>
Where to, where do I go?</br>
朝着何方 我要去何方</br>
If you never try then you'll never know</br>
如果你从不去尝试 你将永远无法知晓</br>
How long do I have to climb</br>
我还得往上攀爬多久呢</br>
Up on the side of this mountain of mine</br>
一直沿着这座山向上爬</p>
</br>
<!--more-->

**当我抬头仰望时，其它所有的一切都以声速在脑后消散，如飞鸟般，你也能看到吗？**

</br>
<p id="div-border-left-purple">Look up, I look up at night</br>
抬头仰望 我在夜里仰望</br>
Planets are moving at the speed of light</br>
行星正以光速急速移动</br>
Climb up, up in the trees</br>
往上爬呀 爬过这片树林</br>
Every chance that you get is a chance you seize</br>
你赢得的每一次机会你都必须抓牢</br>
How long am I gonna stand</br>
我还得伫立多久呢</br>
With my head stuck under the sand</br>
头颅深埋进沙堆里</br>
I start before I can stop or</br>
我会再度启程直到我想要停下</br>
Before I see things the right way up</br>
直到前方事物闯入我的视野</br>
All that noise and all that sound</br>
所有的噪声与喧哗</br>
All those places I got found</br>
我途径找到的所有那些地方</br>
And birds go flying at the speed of sound</br>
飞鸟声速般一哄而散</br>
To show you how it all began</br>
为了向你预示这一切是如何开始</br>
Birds came flying from the underground</br>
群鸟从地底下飞掠上来</br>
If you could see it then you'd understand</br>
如果你见过它们你就会憬悟</br>

</br>

**我一直相信有些神奇的事物在等待着我来创造，有些神秘的谜团在等待着我来解答，群鸟正从地底飞上来，你也能看到吗？**

</br>

<p id="div-border-left-purple">
Ideas that you'll never find</br>
你脑子里从未闪现过的新奇想法</br>
All the inventors could never design</br>
所有的发明家从没有设计过</br>
The buildings that you put up</br>
你精心一手建造的建筑物</br>
But you've been in China all lit up</br>
但你到过辉煌灿烂的中国</br>
A sign that I couldn't read</br>
一个我辨认不出的古老符号</br>
or a light, that I couldn't see</br>
抑或一束我无法直视的光芒</br>
Some things you have to believe</br>
你不得不相信一些事情</br>
When others are puzzles, puzzling me</br>
当其他人就像谜团一样令我困惑不解</br>
All that noise and all that sound</br>
所有的噪声与喧哗</br>
All those places I got found</br>
我途径找到的所有那些地方</br>
And birds go flying at the speed of sound</br>
群鸟从地底下飞掠上来</br>
To show you how it all began</br>
为了向你预示这一切是如何开始</br>
Birds came flying from the underground</br>
群鸟从地底下飞掠上来</br>
If you could see it then you'd understand</br>
如果你见过它们你就会憬悟</br>
Oh, when you see it then you'll understand</br>
噢 当你见过你就会憬悟</p>

</br>

**一直相信，一直攀爬，再次抬头仰望时，其它所有的一切又都以声速在脑后消散，那么现在：**

</br>

<p id="div-border-left-purple">
夫子说：“现在你应该从怠惰中</br>
摆脱出来，因为坐在绒毛上面，</br>
或者睡在被窝里的人是不会成名的；</br>
没有名声而磋砣一生，</br>
人们在人世留下的痕迹，</br>
就像空中的烟云，水上的泡沫；</br>
因此起来吧！用那战胜一切战役的</br>
灵魂来战胜你的气喘，</br>
假使灵魂不和沉重的躯壳一起下沉。</br>
一架更长的梯子还需要爬登：</br>
走过了这些地方还不够；你若懂得我，</br>
那么起来吧，这对你有好处。”^[2]^</p>
</br>
</br>

<center> <font color=black > better die than look back. </center>  

{% meting "3986344" "netease" "song" %}

</br>

<span id="inline-toc">1</span>.尼采：《查拉图斯特拉如是说》（钱春绮译），p39，《读和写》。 ↩
<span id="inline-toc">2</span>.但丁：《神曲》，地狱篇，第二十四歌。 ↩
